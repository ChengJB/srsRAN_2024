// 这个是enb,只负责接受来自route的消息，发送给route

#include <arpa/inet.h>
#include <boost/asio.hpp>
#include <iostream>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>
#include <vector>
using boost::asio::ip::udp;

#define BS_PORT 2152
#define BS_IP "127.0.100.88"
#define CS_PORT 2152
#define CS_IP "127.0.100.99"

#define EPC_PORT 2152
#define EPC_IP "127.0.100.2"

#define ENB_PORT 2152
#define ENB_IP "127.0.100.3"

#define STAR_PORT 2152
#define STAR_IP "127.0.100.10"
// 需要两个route函数，一个转发enb-star的信息，一个转发epc-star的信息

struct Client
{
  struct sockaddr_in addr;
  socklen_t addr_len;
};

void udp_send(Client *client, int bs_fd)
{

  Client toClient = client[2];
  while (1)
  {
    printf("enb enb enb\n");
    // 发送给对应的client, 中间件
    std::string message;
    std::cout << "Enter the message to send: ";
    std::getline(std::cin, message);

    const char *message_data = message.c_str(); // 保持为const char*
    size_t message_len = message.size();
    
    printf("\nSend message to %s:%d\n", inet_ntoa(toClient.addr.sin_addr), ntohs(toClient.addr.sin_port));

    int send_result = sendto(bs_fd, message_data, message_len, 0, reinterpret_cast<struct sockaddr *>(&toClient.addr), toClient.addr_len);
    if (send_result == -1)
    {
      perror("sendto failed");
      // 处理错误
    }
    else if (static_cast<size_t>(send_result) != message_len)
    {
      // 发送的字节数少于预期的字节数，处理错误情况
    }
  }
}
void udp_recv(Client *client, int bs_fd)
{
  struct sockaddr_in from_addr;
  socklen_t from_len = sizeof(from_addr);
  unsigned char buffer[1500];
  while (1)
  {
    std::fill_n(buffer, 1500, 0); // 将buffer的前1500个元素置为零
    int bytes = recvfrom(bs_fd, buffer, sizeof(buffer), 0, (struct sockaddr *)&(from_addr), &(from_len));
     printf("%s\n", buffer);  
    if (bytes <= 0)
    {
      printf("recvfrom error");
      break;
    }
    // 打印收到的消息
    printf("Received message from %s:%d\n", inet_ntoa(from_addr.sin_addr), ntohs(from_addr.sin_port));
  }
}
void routeMessage_enb_star(Client *client, int bs_fd) //
{
  std::thread udp_recv_thread([&]()
                              { udp_recv(client, bs_fd); });
  std::thread udp_send_thread([&]()
                              { udp_send(client, bs_fd); });

  udp_recv_thread.join();
  udp_send_thread.join();
}

int main()
{

  // socket config
  int bs_fd = socket(AF_INET, SOCK_DGRAM, 0); // 用于enb的插座
  if (bs_fd < 0)
  {
    printf("socket error");
    return -1;
  }

  struct sockaddr_in local_bs_addr; // 绑定enb本地地址
  memset(&local_bs_addr, 0, sizeof(local_bs_addr));
  local_bs_addr.sin_family = AF_INET;
  local_bs_addr.sin_port = htons(ENB_PORT);
  local_bs_addr.sin_addr.s_addr = inet_addr(ENB_IP);

  // enb插座地址绑定
  if (bind(bs_fd, (struct sockaddr *)&local_bs_addr, sizeof(local_bs_addr)) < 0)
  {
    printf("bind route error");
    return -1;
  }

  // Client config  , client[0] is EPC,   client[1] is ENB,  client[2] is BS控件
  Client client[2];
  // client[0].addr.sin_family      = AF_INET;
  // client[0].addr.sin_port        = htons(EPC_PORT);
  // client[0].addr.sin_addr.s_addr = inet_addr(EPC_IP);
  // client[0].addr_len             = sizeof(client[0].addr);

  // client[1].addr.sin_family      = AF_INET;
  // client[1].addr.sin_port        = htons(ENB_PORT);
  // client[1].addr.sin_addr.s_addr = inet_addr(ENB_IP);
  // client[1].addr_len             = sizeof(client[1].addr);

  client[2].addr.sin_family = AF_INET;
  client[2].addr.sin_port = htons(BS_PORT);
  client[2].addr.sin_addr.s_addr = inet_addr(BS_IP);
  client[2].addr_len = sizeof(client[2].addr);

  routeMessage_enb_star(client, bs_fd);

  close(bs_fd);

  return 0;
}
