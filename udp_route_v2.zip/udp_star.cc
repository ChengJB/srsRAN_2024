//star是个中间件，接受到来自BS口的消息就发给BS，接收CS口的消息，就发送给CS口
#include <arpa/inet.h>
#include <boost/asio.hpp>
#include <iostream>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>
#include <vector>
using boost::asio::ip::udp;

#define ROUTE_PORT 2152
#define ROUTE_IP "127.0.100.88"

#define BS_PORT 2152
#define BS_IP "127.0.100.88"
#define CS_PORT 2152
#define CS_IP "127.0.100.99"

#define EPC_PORT 2152
#define EPC_IP "127.0.100.2"

#define ENB_PORT 2152
#define ENB_IP "127.0.100.3"

#define STAR_PORT 2152
#define STAR_IP "127.0.100.10"

struct Client {
  struct sockaddr_in addr;
  socklen_t          addr_len;
};
int num=0;
void routeMessage(Client* client, int route_fd)
{
  struct sockaddr_in from_addr;
  socklen_t          from_len = sizeof(from_addr);
  unsigned char      buffer[1500];

  while (1) {
    
    printf("star  star\n");
    int bytes = recvfrom(route_fd, buffer, sizeof(buffer), 0, (struct sockaddr*)&(from_addr), &(from_len));
    printf("%s,%d\n", buffer,bytes);  
    if (bytes <= 0) {
      printf("recvfrom error");
      break;
    }

    // 打印收到的消息
    printf("Received message from %s:%d\n", inet_ntoa(from_addr.sin_addr), ntohs(from_addr.sin_port));


    
    Client toClient = (from_addr.sin_addr.s_addr == inet_addr(BS_IP)) ? client[0] : client[1];

    // 发送给对应的client
    printf("Send message to %s:%d \n", inet_ntoa(toClient.addr.sin_addr), ntohs(toClient.addr.sin_port));
    sendto(route_fd, buffer, bytes, 0, (struct sockaddr*)&(toClient.addr), toClient.addr_len);
  }
}
int main()
{
  // route config
  int route_fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (route_fd < 0) {
    printf("socket error");
    return -1;
  }

  struct sockaddr_in route_addr;
  memset(&route_addr, 0, sizeof(route_addr));
  route_addr.sin_family      = AF_INET;
  route_addr.sin_port        = htons(STAR_PORT);//绑定STAR地址
  route_addr.sin_addr.s_addr = inet_addr(STAR_IP);

  if (bind(route_fd, (struct sockaddr*)&route_addr, sizeof(route_addr)) < 0) {
    printf("bind route error");
    return -1;
  }
  // Client config  , client[0] is EPC,   client[1] is ENB
  Client client[2];
  client[0].addr.sin_family      = AF_INET;
  client[0].addr.sin_port        = htons(BS_PORT);
  client[0].addr.sin_addr.s_addr = inet_addr(BS_IP);
  client[0].addr_len             = sizeof(client[0].addr);

  client[1].addr.sin_family      = AF_INET;
  client[1].addr.sin_port        = htons(CS_PORT);
  client[1].addr.sin_addr.s_addr = inet_addr(CS_IP);
  client[1].addr_len             = sizeof(client[1].addr);

  routeMessage(client, route_fd);

  close(route_fd);

  return 0;
}