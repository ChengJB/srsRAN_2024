/*
程序逻辑说明：

enb-star-epc    epc-star-enb
声明两个套接字bs和cs，用于接收两个不同流的信息，所以一个套接字只会接收到一个流的信息
声明两套转发函数用于转发两个流的数据，因为有套接字做区分，所以一个函数内的接收函数只会接收一个流的信息

于是在转发函数的内部，能够根据地址对流向做区分。

*/




#include <arpa/inet.h>
#include <boost/asio.hpp>
#include <iostream>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>
#include <vector>
using boost::asio::ip::udp;

#define BS_PORT 2152
#define BS_IP "127.0.100.88"
#define CS_PORT 2152
#define CS_IP "127.0.100.99"

#define EPC_PORT 2152
#define EPC_IP "127.0.100.2"

#define ENB_PORT 2152
#define ENB_IP "127.0.100.3"

#define STAR_PORT 2152
#define STAR_IP "127.0.100.10"
//需要两个route函数，一个转发enb-star的信息，一个转发epc-star的信息

struct Client {
  struct sockaddr_in addr;
  socklen_t          addr_len;
};

typedef struct StarNetworkMsg {
  int     flag;
  short   srcId;
  short   dstId;
  int     dataType;
  int     dataID;
  int     N_bytes;

} star_network_msg;
void print_buffer_as_string(int bytes,unsigned char buffer[]) 
{  
        printf("%s\n", buffer);  
}  

void add_header_to_buffer_bs( int bytes, unsigned char buffer[])
{
  //此处需要判断语句来判断数据流向
  star_network_msg star_msg;
  star_msg.flag     = htonl(0xFFFFFFFF);
  star_msg.srcId    = htons(85);
  star_msg.dstId    = htons(59);
  star_msg.dataType = htonl(3);
  star_msg.dataID   = htonl(4);
  star_msg.N_bytes  = bytes;
  memmove( buffer+20, buffer, bytes);
  memcpy( buffer, &star_msg, 20);
  
  print_buffer_as_string(bytes,buffer);
}
void add_header_to_buffer_cs( int bytes, unsigned char buffer[])
{
  //此处需要判断语句来判断数据流向
  star_network_msg star_msg;
  star_msg.flag     = htonl(0xFFFFFFFF);
  star_msg.srcId    = htons(85);
  star_msg.dstId    = htons(59);
  star_msg.dataType = htonl(3);
  star_msg.dataID   = htonl(4);
  star_msg.N_bytes  = bytes;
  memmove( buffer+20, buffer, bytes);
  memcpy( buffer, &star_msg, 20);
  
  print_buffer_as_string(bytes+20,buffer);
}

void rmv_header_from_buffer( int bytes,unsigned char buffer[])
{

unsigned char msg[1500];
std::fill_n(msg, 1500, 0);
memcpy( msg, buffer+20, bytes-20);
std::fill_n(buffer, 1500, 0);
print_buffer_as_string(bytes,buffer);
memcpy( buffer, msg, bytes-20);

}


void routeMessage_enb_star(Client* client, int bs_fd)//
{
  //enb-star-epc间的转发工作，接收到enb消息后加头发送给star，接收到star消息后去头发送给epc
  //初步考虑需要写一个加头去头的函数

  struct sockaddr_in from_addr;
  socklen_t          from_len = sizeof(from_addr);
  unsigned char      buffer[1500];
  while (1) {
    std::fill_n(buffer, 1500, 0); // 将buffer的前1500个元素置为零
    printf(" enb-star-epc \n ");
    int bytes = recvfrom(bs_fd, buffer, sizeof(buffer), 0, (struct sockaddr*)&(from_addr), &(from_len));
    if (bytes <= 0) {
      printf("recvfrom error");
      break;
    }
    print_buffer_as_string(bytes,buffer);
    // 打印收到的消息
    printf("Received message from %s:%d\n", inet_ntoa(from_addr.sin_addr), ntohs(from_addr.sin_port));

    Client toClient;
    //如果接收到enb的消息，目的地址设为STAR，否则设为EPC
    if(from_addr.sin_addr.s_addr == inet_addr(ENB_IP))
    {
      toClient=client[2];
      //来自enb的消息需要加头
      add_header_to_buffer_bs(bytes,buffer);
      bytes=bytes+20;
      printf("加头bytes:%d\n",bytes);
    }
    else//接收到STAR发给EPC
    {
      toClient=client[0];
      //来自STAR的消息需要去头
      rmv_header_from_buffer(bytes,buffer);
      bytes=bytes-20;
      printf("去头bytes:%d\n",bytes);

    }

    //Client toClient = (from_addr.sin_addr.s_addr == inet_addr(ENB_IP)) ? client[2] : client[0];

    // 发送给对应的client,  epc or star
    printf("Send message to %s:%d \n", inet_ntoa(toClient.addr.sin_addr), ntohs(toClient.addr.sin_port));
    sendto(bs_fd, buffer, bytes, 0, (struct sockaddr*)&(toClient.addr), toClient.addr_len);
    printf("route end=========================\n");
  }
}
void routeMessage_epc_star(Client* client, int cs_fd)
{
  //epc-star-enb间的转发工作

  struct sockaddr_in from_addr;
  socklen_t          from_len = sizeof(from_addr);
  unsigned char      buffer[1500];

  while (1) {
    std::fill_n(buffer, 1500, 0); // 将buffer的前1500个元素置为零
    printf("epc-star-enb\n");
    int bytes = recvfrom(cs_fd, buffer, sizeof(buffer), 0, (struct sockaddr*)&(from_addr), &(from_len));
    if (bytes <= 0) {
      printf("recvfrom error");
      break;
    }
    // 打印收到的消息
    print_buffer_as_string(bytes,buffer);
    printf("Received message from %s:%d\n", inet_ntoa(from_addr.sin_addr), ntohs(from_addr.sin_port));

    Client toClient;
    //如果接收到epc的消息，目的地址设为STAR，否则设为enb
    if(from_addr.sin_addr.s_addr == inet_addr(EPC_IP))
    {
      toClient=client[2];
      //来自epc的消息需要加头
      add_header_to_buffer_bs(bytes,buffer);
      bytes=bytes+20;
      printf("加头bytes:%d\n",bytes);
    }
    else//接收到STAR发给enb
    {
      toClient=client[1];
      //来自STAR的消息需要去头
      rmv_header_from_buffer(bytes,buffer);
      bytes=bytes-20;
      printf("去头bytes:%d\n",bytes);

    }
    

    // 发送给对应的client
    printf("Send message to %s:%d \n", inet_ntoa(toClient.addr.sin_addr), ntohs(toClient.addr.sin_port));
    sendto(cs_fd, buffer, bytes, 0, (struct sockaddr*)&(toClient.addr), toClient.addr_len);
  }
}
int main()
{

  // socket config
  int bs_fd = socket(AF_INET, SOCK_DGRAM, 0);//用于enb-star的插座
  if (bs_fd < 0) {
    printf("socket error");
    return -1;
  }
  int cs_fd = socket(AF_INET, SOCK_DGRAM, 0);//用于epc-star的插座
  if (cs_fd < 0) {
    printf("socket error");
    return -1;
  }
  struct sockaddr_in local_bs_addr;          //enb-star插座地址声明
  memset(&local_bs_addr, 0, sizeof(local_bs_addr));
  local_bs_addr.sin_family      = AF_INET;
  local_bs_addr.sin_port        = htons(BS_PORT);
  local_bs_addr.sin_addr.s_addr = inet_addr(BS_IP);

  struct sockaddr_in local_cs_addr;            //epc-star插座地址声明
  memset(&local_cs_addr, 0, sizeof(local_cs_addr));
  local_cs_addr.sin_family      = AF_INET;
  local_cs_addr.sin_port        = htons(CS_PORT);
  local_cs_addr.sin_addr.s_addr = inet_addr(CS_IP);
  //enb-star插座地址绑定
  if (bind(bs_fd, (struct sockaddr*)&local_bs_addr, sizeof(local_bs_addr)) < 0) {
    printf("bind route error");
    return -1;
  }

  //epc-star插座地址绑定
  if (bind(cs_fd, (struct sockaddr*)&local_cs_addr, sizeof(local_cs_addr)) < 0) {
    printf("bind route error");
    return -1;
  }
  // Client config  , client[0] is EPC,   client[1] is ENB,  client[2] is STAR
  Client client[3];
  client[0].addr.sin_family      = AF_INET;
  client[0].addr.sin_port        = htons(EPC_PORT);
  client[0].addr.sin_addr.s_addr = inet_addr(EPC_IP);
  client[0].addr_len             = sizeof(client[0].addr);

  client[1].addr.sin_family      = AF_INET;
  client[1].addr.sin_port        = htons(ENB_PORT);
  client[1].addr.sin_addr.s_addr = inet_addr(ENB_IP);
  client[1].addr_len             = sizeof(client[1].addr);

  client[2].addr.sin_family      = AF_INET;
  client[2].addr.sin_port        = htons(STAR_PORT);
  client[2].addr.sin_addr.s_addr = inet_addr(STAR_IP);
  client[2].addr_len             = sizeof(client[2].addr);
  
  
  std::thread enb_star_thread([&]()   { routeMessage_enb_star(client, bs_fd); });
  std::thread epc_star_thread([&]()   { routeMessage_epc_star(client, cs_fd); });
  enb_star_thread.join();
  epc_star_thread.join();
  close(bs_fd);
  close(cs_fd);
  
  return 0;
}