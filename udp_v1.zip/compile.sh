g++ -o udp_enb udp_enb.cc
g++ -o udp_epc udp_epc.cc
g++ -o udp_route udp_route.cc
g++ -o udp_star udp_star.cc



gnome-terminal --command="bash -c './udp_enb; exec bash'"
gnome-terminal --command="bash -c './udp_epc; exec bash'"
gnome-terminal --command="bash -c './udp_route; exec bash'"
gnome-terminal --command="bash -c './udp_star; exec bash'"



